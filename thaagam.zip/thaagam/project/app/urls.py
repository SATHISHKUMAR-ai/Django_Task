from django.urls import path
from . import views

urlpatterns = [
    path('', views.register_view, name='register'),
    # path('', views.home_view, name='home'),
    path('register/', views.register_view, name='register'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('post_list', views.post_list, name='post_list'),
    path('add/', views.post_add, name='post_add'),
    path('like/<int:post_id>/', views.post_like, name='post_like'),
]